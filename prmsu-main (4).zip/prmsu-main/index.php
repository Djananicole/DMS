<?php
include('components/header.php');
?>
<main class="container d-flex flex-column align-items-center mt-5">
    <a class="btn btn-dark m-2 btn-pick-user-type" href="login.php?user=admin">ADMINISTRATOR</a>
    <a class="btn btn-dark m-2 btn-pick-user-type" href="login.php?user=faculty">FACULTY</a>
</main>
<?php
include('components/footer.php');
