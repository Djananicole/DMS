<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/login.js"></script>
</body>

</html>